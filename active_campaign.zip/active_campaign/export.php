<?php
error_reporting(0);

$url = 'https://egenienext.api-us1.com';

$params = array(

  
  'api_key' => '10fd59e946e0be4bb84608004eddbfc5828b9acee534b167d6449015fca2fc69801116d4',

  'api_action' => 'contact_list',

  'api_output' => 'serialize',

  'ids' => 'all',

  'full' => 0,

);

$query = "";
foreach( $params as $key => $value ) $query .= urlencode($key) . '=' . urlencode($value) . '&';

$query = rtrim($query, '& ');


$url = rtrim($url, '/ ');


if ( !function_exists('curl_init') ) die('CURL not supported. (introduced in PHP 4.0.2)');


if ( $params['api_output'] == 'json' && !function_exists('json_decode') ) {
    die('JSON not supported. (introduced in PHP 5.2.0)');
}


$api = $url . '/admin/api.php?' . $query;



$request = curl_init($api); 
curl_setopt($request, CURLOPT_HEADER, 0);
curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); 

curl_setopt($request, CURLOPT_FOLLOWLOCATION, true);

$response = (string)curl_exec($request);

curl_close($request);

if ( !$response ) {
    die('Nothing was returned. Do you have a connection to Email Marketing server?');
}

$result = unserialize($response);
$count = count($result);
$results = array(array("Name", "Email"));
foreach ($result as $contact) {

	$name = $contact['first_name']." ".$contact['last_name']; 

	if($contact['first_name'] == ''){
		break;
	}
	
    $results[] = array($name, $contact['email']);
}



download_csv_results($results, 'Contacts.csv', $count);

//Function to genertae CSV file
function download_csv_results($results, $name = NULL, $count) {

    if (!$name) {
        $name = md5(uniqid() . microtime(TRUE) . mt_rand()) . '.csv';
    }
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename=' . $name);
    header('Pragma: no-cache');
    header("Expires: 0");
    $outstream = fopen("php://output", "w");
    foreach ($results as $key => $result) {

	    fputcsv($outstream, $result);
        
    }
    fclose($outstream);
}

?>