<?php

    $error = array();
    $submited = array();

    $url = 'https://egenienext.api-us1.com';


    $params = array(

        'api_key'      => '10fd59e946e0be4bb84608004eddbfc5828b9acee534b167d6449015fca2fc69801116d4',

        'api_action'   => 'contact_add',

        'api_output'   => 'serialize',
    );

     //Validate CSV file
    $fileName = explode('.', $_FILES['csvFile']['name']);
    $extension = end($fileName);

    if ($extension == 'csv') {
        $FileToRead = fopen($_FILES['csvFile']['tmp_name'], 'r+');
        //Save file into Array() 
        $csv = array();
        while (($row = fgetcsv($FileToRead, 9999)) !== FALSE) {
            $csv[] = $row;
        } 
    
        $countRow = count($csv);

        for($i=0; $i<$countRow; $i++){
            $post = array(
                'email'                    => $csv[$i][0],
                'first_name'               => $csv[$i][1],
                'last_name'                => $csv[$i][2],
                'phone'                    => $csv[$i][3],
                'orgname'                  => $csv[$i][4],
                'field[%Picture%,0]'       => $csv[$i][5],
                "p[{1}]"            => 1,
                "status[{1}]"       => 1, // "Active" status
            );

            $query = "";
            foreach( $params as $key => $value ) $query .= urlencode($key) . '=' . urlencode($value) . '&';
            $query = rtrim($query, '& ');

            $data = "";
            foreach( $post as $key => $value ) $data .= urlencode($key) . '=' . urlencode($value) . '&';
            $data = rtrim($data, '& ');

            $url = rtrim($url, '/ ');

            if ( !function_exists('curl_init') ) die('CURL not supported. (introduced in PHP 4.0.2)');

            
            if ( $params['api_output'] == 'json' && !function_exists('json_decode') ) {
                die('JSON not supported. (introduced in PHP 5.2.0)');
            }

            
            $api = $url . '/admin/api.php?' . $query;

            $request = curl_init($api); 
            curl_setopt($request, CURLOPT_HEADER, 0); 
            curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); 

            curl_setopt($request, CURLOPT_POSTFIELDS, $data); 

            curl_setopt($request, CURLOPT_FOLLOWLOCATION, true);

            $response = (string)curl_exec($request); 

            curl_close($request);

            if ( !$response ) {
                die('Nothing was returned. Do you have a connection to Email Marketing server?');
            }

            $result = unserialize($response);
        
            if ($result['result_code']) {
                $submited[] =  $csv[$i][0];
            } else {
                $error[] =  $csv[$i][0];
            }
            
}
      
   
    }

    $file = fopen("contacts.csv","r");


    // while(! feof($file))
    // {
      
    //     $d1 = fgetcsv($file);

    //     $post = array(
    //         'email'                    => $d1['0'],
    //         'first_name'               => $d1['1'],
    //         'last_name'                => $d1['2'],
    //         'phone'                    => $d1['3'],
    //         'orgname'                  => $d1['4'],
    //         'field[%Picture%,0]'       => $d1['5'],
    //         "p[{1}]"            => 1,
    //         "status[{1}]"       => 1, // "Active" status
    //     );

        
    //     $query = "";
    //     foreach( $params as $key => $value ) $query .= urlencode($key) . '=' . urlencode($value) . '&';
    //     $query = rtrim($query, '& ');

    //     $data = "";
    //     foreach( $post as $key => $value ) $data .= urlencode($key) . '=' . urlencode($value) . '&';
    //     $data = rtrim($data, '& ');

    //     $url = rtrim($url, '/ ');

    //     if ( !function_exists('curl_init') ) die('CURL not supported. (introduced in PHP 4.0.2)');

        
    //     if ( $params['api_output'] == 'json' && !function_exists('json_decode') ) {
    //         die('JSON not supported. (introduced in PHP 5.2.0)');
    //     }

        
    //     $api = $url . '/admin/api.php?' . $query;

    //     $request = curl_init($api); 
    //     curl_setopt($request, CURLOPT_HEADER, 0); 
    //     curl_setopt($request, CURLOPT_RETURNTRANSFER, 1); 

    //     curl_setopt($request, CURLOPT_POSTFIELDS, $data); 

    //     curl_setopt($request, CURLOPT_FOLLOWLOCATION, true);

    //     $response = (string)curl_exec($request); 

    //     curl_close($request);

    //     if ( !$response ) {
    //         die('Nothing was returned. Do you have a connection to Email Marketing server?');
    //     }

    //     $result = unserialize($response);

    //     if ($result['result_code']) {
    //         $submited[] = $d1['0'];
    //     } else {
    //         $error[] = $d1['0'];
    //     }

    // }

    fclose($file);

    echo 'SUBMITTION RESULT<br>';
    echo '<br>';
    if(count($submited) > 0){
        echo 'The given contact is added successfully in contact list whose email listed below: <br>';
        foreach ($submited as $key => $value) {
           echo $key.') '. $value;
           echo '<br>';
        }
        echo '<br>';
    }    
    
    if (count($error) > 0) {
        echo 'The given Email already present in contact list which is listed below: <br>';
        foreach ($error as $key => $value) {
           echo $key.') '. $value;
           echo '<br>';
        }
    } 
    

?>